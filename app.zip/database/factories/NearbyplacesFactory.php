<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Nearbyplaces;
use Faker\Generator as Faker;

$factory->define(Nearbyplaces::class, function (Faker $faker) {
    return [
        //
    ];
});
