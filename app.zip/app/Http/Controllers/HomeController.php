<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;
use App\Building;
use App\Room;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $best = Building::first();
        $buildings = Building::limit(4)->latest()->get();
        $rooms = Room::all();
        return view('welcome',compact('buildings','best','rooms'));
    }

    public function room($id)
    {
        $buildings = Building::all();
        $room = Room::where('id',$id)->first();
        return view('room-details',compact('room','buildings'));
    }

    public function profile()
    {
        return view('user.profile');
    }

    public function updateProfile(Request $request)
    {
        $user = User::where('id',Auth::User()->id)->first();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->number = $request->number;
        $user->save();
        return redirect()->back();
    }


}
