<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GalleryRoom extends Model
{
    //
}
