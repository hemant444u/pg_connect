

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Nearbyplaces</a></li>
              <li class="breadcrumb-item active">edit</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <span>Edit nearby places</span>
              <span><a href="<?php echo e(route('building.index')); ?>" class="btn btn-sm btn-primary float-sm-right">Back</a></span>
            </div>
            <div class="card-body">
              <form action="<?php echo e(route('nearbyplaces.update',$nearbyplaces->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <label for="type">Building</label>
                    <select name="building" class="form-control" required>
                      <?php $__empty_1 = true; $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($building->id); ?>" <?php echo e($building->id == $nearbyplaces->building_id ? 'selected' : ''); ?>><?php echo e($building->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <?php endif; ?>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label for="place">Place</label>
                    <select name="place" class="form-control">
                      <option value="Company" <?php echo e($nearbyplaces->place == 'Company' ? 'selected' : ''); ?>>Company</option>
                      <option value="Hotel" <?php echo e($nearbyplaces->place == 'Hotel' ? 'selected' : ''); ?>>Hotel</option>
                      <option value="Temple" <?php echo e($nearbyplaces->place == 'Temple' ? 'selected' : ''); ?>>Temple</option>
                    </select>                  
                  </div>
                </div>

                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($nearbyplaces->name); ?>" required>
                  </div>
                  <div class="col-md-6">
                    <label for="distance">Distance from building</label>
                    <div class="input-group">
                    <input type="text" class="form-control" name="distance" value="<?php echo e($nearbyplaces->distance); ?>" required>
                      <div class="input-group-append">
                        <span class="input-group-text" id="basic-addon2">Km</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <label for="photo">Photo</label>
                    <img src="<?php echo e(url($nearbyplaces->photo)); ?>" alt="photo" width="100" height="100">
                    <input type="file" class="form-control" name="photo" accept="image/*">
                  </div>
                  <div class="col-md-6">
                    <label for="video">Video</label>
                    <video src="<?php echo e(url($nearbyplaces->video)); ?>" type="video/*" width="100" height="100" autoplay controls></video>
                    <input type="file" class="form-control" name="video" accept="video/*">
                  </div>
                </div>

                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <input type="reset" class="btn btn-warning btn-block" value="Reset">
                  </div>
                  <div class="col-md-6">
                    <input type="submit" class="btn btn-primary btn-block" value="Save">
                  </div>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.owner_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\websites\arvind_infosis\pg\resources\views/owner/nearbyplaces/edit.blade.php ENDPATH**/ ?>