

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Room availabelity</a></li>
              <li class="breadcrumb-item active">edit</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <span>Edit room</span>
              <span><a href="<?php echo e(route('room.index')); ?>" class="btn btn-sm btn-primary float-sm-right">Back</a></span>
            </div>
            <div class="card-body">
              <form action="<?php echo e(route('room.update',$room->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <label for="type">Building</label>
                    <select name="building" class="form-control" required>
                      <?php $__empty_1 = true; $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($building->id); ?>" <?php echo e($building->id == $room->building->id ? 'selected' : ''); ?>><?php echo e($building->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                      <?php endif; ?>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label for="Name">Room No</label>
                    <input type="number" class="form-control" name="room_no" value="<?php echo e($room->room_no); ?>" required>
                  </div>
                </div>

                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <label for="Name">Toal Bed</label>
                    <input type="number" class="form-control" name="bed" value="<?php echo e($room->bed); ?>" required placeholder="count bed in this room">
                  </div>
                  <div class="col-md-6">
                    <label for="Name">Total Renter can live</label>
                    <input type="number" class="form-control" name="renter" value="<?php echo e($room->renter); ?>" required placeholder="count of renters can live in this room">
                  </div>
                </div>

                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <label for="slug">Available beds</label>
                    <input type="number" name="available" value="<?php echo e($room->available); ?>" class="form-control" required>
                  </div>
                  <div class="col-md-6">
                    <label for="slug">Max rent</label>
                    <input type="number" class="form-control" name="max_rent" value="<?php echo e($room->max_rent); ?>" required>
                  </div>
                </div>
                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <label for="slug">Room photo</label>
                    <img src="<?php echo e(url($room->photo)); ?>" alt="photo" height="30" width="30">
                    <input type="file" class="form-control" name="banner" accept="image/*">
                  </div>
                  <div class="col-md-6">
                    <label for="slug">Video</label>
                    <input type="number" name="video" class="form-control">
                  </div>
                </div>

                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <input type="reset" class="btn btn-warning btn-block" value="Reset">
                  </div>
                  <div class="col-md-6">
                    <input type="submit" class="btn btn-primary btn-block" value="Update room">
                  </div>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.owner_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\websites\arvind_infosis\pg\resources\views/owner/room/edit.blade.php ENDPATH**/ ?>