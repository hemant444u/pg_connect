

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Nearbyplaces</a></li>
              <li class="breadcrumb-item active">create</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="col-md-12">
        <?php $__empty_1 = true; $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-12">
          <div class="card">
            <div class="card-header"><?php echo e($building->name); ?>

              <a href="<?php echo e(route('nearbyplaces.create')); ?>" class="btn btn-sm btn-primary float-sm-right">Add new</a>
            </div> 
            <div class="card-body">
              <div class="row"> 
                <?php $__empty_2 = true; $__currentLoopData = $building->nearbyplaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nearby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                  <div class="col-3">
                    <div class="card">
                      <div class="card-body">
                        <img src="<?php echo e($nearby->photo); ?>" alt="photo" width="204">
                        <div class="pt-2">
                          <small><?php echo e($nearby->place); ?>: <?php echo e($nearby->name); ?></small>
                        </div>
                        <small>Distance: <?php echo e($nearby->distance); ?> Km</small>
                        <div class="float-sm-right">
                          <a href="<?php echo e(route('nearbyplaces.edit',$nearby->id)); ?>" class="btn btn-xs btn-primary"><i class="fa fa-edit"></i></a>
                          <a href="#" class="btn btn-xs btn-danger" onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($nearby->id); ?>').submit();"><i class="fa fa-trash"></i></a>

                          <form id="delete-form-<?php echo e($nearby->id); ?>" action="<?php echo e(route('nearbyplaces.destroy', $nearby->id)); ?>" method="POST" style="display:none;">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.owner_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\websites\arvind_infosis\pg\resources\views/owner/nearbyplaces/index.blade.php ENDPATH**/ ?>