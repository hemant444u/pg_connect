<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ashion Template">
    <meta name="keywords" content="Ashion, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ashion | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cookie&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
    rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(url('ashion/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('ashion/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('ashion/css/elegant-icons.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('ashion/css/jquery-ui.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('ashion/css/magnific-popup.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('ashion/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('ashion/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('ashion/css/style.css')); ?>" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Offcanvas Menu Begin -->
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__close">+</div>
        <ul class="offcanvas__widget">
            <li><span class="icon_search search-switch"></span></li>
            <li><a href="#"><span class="icon_heart_alt"></span>
                <div class="tip">2</div>
            </a></li>
            <li><a href="#"><span class="icon_bag_alt"></span>
                <div class="tip">2</div>
            </a></li>
        </ul>
        <div class="offcanvas__logo">
            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('ashion/img/logo.png')); ?>" alt=""></a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <div class="offcanvas__auth">
            <a href="<?php echo e(route('login')); ?>">Login</a>
            <a href="<?php echo e(route('login')); ?>">Register</a>
        </div>
    </div>
    <!-- Offcanvas Menu End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-lg-2">
                    <div class="header__logo">
                        <a href="<?php echo e(url('/')); ?>">
                        <span style="color:red;font-family:Cookie, cursive;font-size:24px;">PG </span>
                        <span style="color:black;font-family:Cookie, cursive;font-size:24px;"> Connect</span>
                        </a>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-7">
                    <nav class="header__menu">
                        <ul>
                            <li class="active"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                            <li><a href="#">About</a></li>
                            <li><a href="#">PG</a></li>
                            <li><a href="#">Hostel</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Contact</a></li>
                            <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::User()->role == 'owner' || Auth::User()->role == 'broker'): ?>
                            <li><a href="<?php echo e(url('owner/dashboard')); ?>">Dashboard</a></li>
                            <?php endif; ?>
                            <?php endif; ?>

                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3">
                    <div class="header__right">
                        <div class="header__right__auth">
                            <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e('profile'); ?>"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSTCbuwzBWsYE-bms_JeMfSN_TMoSjUWljbjw&usqp=CAU" alt="profile" width="20" height="20">
                                <?php echo e(Auth::User()->name); ?>

                            </a>
                            <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>">Login</a>
                            <a href="<?php echo e(route('login')); ?>">Register</a>
                            <?php endif; ?>
                        </div>
                        <ul class="header__right__widget">
                            <li><span class="icon_search search-switch"></span></li>
                            <li><a href="#"><span class="icon_heart_alt"></span>
                                <div class="tip">2</div>
                            </a></li>
                            <li><a href="#"><span class="icon_bag_alt"></span>
                                <div class="tip">2</div>
                            </a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="canvas__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <?php echo $__env->yieldContent('content'); ?>


    <!-- Instagram Begin -->
<div class="instagram">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('ashion/img/instagram/insta-1.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ pg_connect</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('ashion/img/instagram/insta-2.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ pg_connect</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('ashion/img/instagram/insta-3.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ pg_connect</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('ashion/img/instagram/insta-4.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ pg_connect</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('ashion/img/instagram/insta-5.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ pg_connect</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('ashion/img/instagram/insta-6.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ pg_connect</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Instagram End -->

<!-- Footer Section Begin -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-7">
                <div class="footer__about">
                    <div class="footer__logo categories__text">
                        <a href="<?php echo e(url('/ecommerce')); ?>">
                        <span style="color:red;font-family:Cookie, cursive;font-size:36px;">PG </span>
                        <span style="color:black;font-family:Cookie, cursive;font-size:36px;"> Connect</span>
                        </a>
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                    cilisis.</p>
                    <div class="footer__payment">
                        <a href="#"><img src="<?php echo e(url('ashion/img/payment/payment-1.png')); ?>" alt=""></a>
                        <a href="#"><img src="<?php echo e(url('ashion/img/payment/payment-2.png')); ?>" alt=""></a>
                        <a href="#"><img src="<?php echo e(url('ashion/img/payment/payment-3.png')); ?>" alt=""></a>
                        <a href="#"><img src="<?php echo e(url('ashion/img/payment/payment-4.png')); ?>" alt=""></a>
                        <a href="#"><img src="<?php echo e(url('ashion/img/payment/payment-5.png')); ?>" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-5">
                <div class="footer__widget">
                    <h6>Quick links</h6>
                    <ul>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Blogs</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4">
                <div class="footer__widget">
                    <h6>Account</h6>
                    <ul>
                        <li><a href="#">My Account</a></li>
                        <li><a href="#">Orders Tracking</a></li>
                        <li><a href="#">Checkout</a></li>
                        <li><a href="#">Wishlist</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-8 col-sm-8">
                <div class="footer__newslatter">
                    <h6>NEWSLETTER</h6>
                    <form action="#">
                        <input type="text" placeholder="Email">
                        <button type="submit" class="site-btn">Subscribe</button>
                    </form>
                    <div class="footer__social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-youtube-play"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                        <a href="#"><i class="fa fa-pinterest"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                <div class="footer__copyright__text">
                    <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
                </div>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End -->

<!-- Search Begin -->
<div class="search-model">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-switch">+</div>
        <form class="search-model-form">
            <input type="text" id="search-input" placeholder="Search here.....">
        </form>
    </div>
</div>
<!-- Search End -->

<!-- Js Plugins -->
<script src="<?php echo e(url('ashion/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/mixitup.min.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/jquery.slicknav.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(url('ashion/js/main.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH E:\websites\arvind_infosis\pg\resources\views/layouts/ecommerce_master.blade.php ENDPATH**/ ?>