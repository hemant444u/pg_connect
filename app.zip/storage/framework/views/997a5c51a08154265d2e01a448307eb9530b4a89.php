

<?php $__env->startSection('head'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(url('adminlte3/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('adminlte3/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            Dashboard
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Pg/Hostel</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

        <!-- Main content -->
    <?php $address = Auth::User()->address; ?>
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <span>Edit Address</span>
            </div>
            <div class="card-body">
              <form action="<?php echo e(route('address.update',$address->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="country">Country</label>
                    <select name="country" class="form-control country" required>
                      <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($country->id); ?>" <?php echo e($country->id == $address->country || $country->id == $s_country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <?php endif; ?>
                    </select>             
                  </div>
                  <div class="form-group">
                    <label for="state">State</label>
                    <select name="state" class="form-control state" required>
                      <?php $__empty_1 = true; $__currentLoopData = $s_country->states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($state->id); ?>" <?php echo e($state->id == $address->state ? 'selected' : ''); ?>><?php echo e($state->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <?php endif; ?>
                    </select>                  
                  </div>

                  <div class="form-group">
                    <label for="slug">District</label>
                    <select name="district" class="form-control district" required>
                      <?php $__empty_1 = true; $__currentLoopData = $s_state->districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($district->id); ?>" <?php echo e($district->id == $address->district ? 'selected' : ''); ?>><?php echo e($district->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <?php endif; ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="slug">City</label>
                    <input type="text" class="form-control" name="city" value="<?php echo e($address->city); ?>" required>
                  </div>
                  <div class="form-group">
                    <label for="slug">Area</label>
                    <input type="text" name="area" class="form-control" value="<?php echo e($address->area); ?>" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <label for="slug">Landmark</label>
                  <input type="hidden" name="lat" class="form-control" id="lat" value="<?php echo e($address->lat); ?>">
                  <input type="hidden" name="lng" class="form-control" id="lng" value="<?php echo e($address->lng); ?>">
                  <div id="map" style="height: 380px;"></div>
                </div>
              </div>

                <div class="form-group d-flex">
                  <div class="col-md-6">
                    <input type="reset" class="btn btn-warning btn-block" value="Reset">
                  </div>
                  <div class="col-md-6">
                    <input type="submit" class="btn btn-primary btn-block" value="Update Address">
                  </div>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
  </div>
  <?php $__env->startSection('script'); ?>
  <script>
    function initMap(){
      var lat = <?php echo e($address->lat ? $address->lat : 23.344315); ?>;
      var lng = <?php echo e($address->lng ? $address->lng : 85.296013); ?>;
      var options = {
        zoom:8,
        center:{lat:lat,lng:lng},
      }

      // New map
      var map = new google.maps.Map(document.getElementById('map'), options);
      // Listen for click on map
      google.maps.event.addListener(map, 'click', function(event){
        // Add marker
        deleteMarkers();
        setlat({coords:event.latLng});
        addMarker({coords:event.latLng});
      });
      var oldmarkers = [
        {
          coords:{lat:lat,lng:lng},
          iconImage:'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png',
          content:'<h6><small>Name: </small><?php echo e(Auth::User()->name); ?></h6><h6><small>Address: </small><?php echo e($address->area); ?></h6>'

        }
      ];
      defaultMarker(oldmarkers[0]);
      function defaultMarker(props){
        var oldmarker = new google.maps.Marker({
            position:props.coords,
            map:map,
            //icon:props.iconImage
          });

        // Check for customicon
        if(props.iconImage){
          // Set icon image
          oldmarker.setIcon(props.iconImage);
        }

        // Check content
        if(props.content){
          var infoWindow = new google.maps.InfoWindow({
            content:props.content
          });

          oldmarker.addListener('click', function(){
            infoWindow.open(map, oldmarker);
          });
        }
      }
        var markers = [];

      // Add Marker Function
      function addMarker(props){
        var marker = new google.maps.Marker({
          position:props.coords,
          map:map,
          //icon:props.iconImage
        });
        markers.push(marker);
      }
      function deleteMarkers() {
        clearMarkers();
        markers = [];
      }
      function clearMarkers() {
        setMapOnAll(null);
      }
      function setMapOnAll(map) {
        for (let i = 0; i < markers.length; i++) {
          markers[i].setMap(map);
        }
      }
      function setlat(props){
        document.getElementById('lat').value = props.coords.lat();
        document.getElementById('lng').value = props.coords.lng();
      }

    }
  </script>
    <script async defer
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD2Zz2EofU165j4EdzGkK2klri-napBfIY&callback=initMap">
    </script>

  <script>
    $(document).ready(function(){
      var url = "<?php echo e(route('address.index')); ?>";
      var country = '?country=<?php echo e($s_country
        ->id); ?>';

      $(document).on('change','.country',function(){
        country = "?country=" + $(this).val();
        window.location.href = url + country;
      });

      $(document).on('change','.state',function(){
        var url = "<?php echo e(route('address.index')); ?>";
        var state = country + "&state=" + $(this).val();
        window.location.href = url + state;
      });

    });
  </script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.owner_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\websites\arvind_infosis\pg\resources\views/owner/address/index.blade.php ENDPATH**/ ?>