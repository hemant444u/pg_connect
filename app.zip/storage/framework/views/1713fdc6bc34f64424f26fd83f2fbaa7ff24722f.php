<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(url('/bxslider-4-4.2.12/dist/jquery.bxslider.css')); ?>">
    <script src="<?php echo e(url('/bxslider-4-4.2.12/dist/jquery.bxslider.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

    </div>
</div>

    <section>
        <div class="front">
            
        </div>
    </section>
    
    <section>
        
    </section>

    <section>
        <ul class="bxslider">
            
            <li><img src="<?php echo e(url('images/logo/pgconnect.png')); ?>" alt="" style="width:100%; height:auto; max-height: 580px;"></li>
            <video src="<?php echo e(url('videoes/test.mp4')); ?>" type="video/*" poster="" style="width:100%; height:auto; max-height: 580px; padding-bottom: 36px;" controls></video>
            
            <li><img src="<?php echo e(url('images/logo/pgconnect.png')); ?>" alt="" style="width:100%; height:auto; max-height: 580px;"></li>
        </ul>
    </section>

<style>
    .front{background-image: url("https://images.unsplash.com/photo-1587202135147-b82e6e3022b0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80");background-size:cover;background-repeat:no-repeat;
    background-attachment:fixed;height:580px;}
</style>
<script>
    $(document).ready(function() {

        $('.bxslider').bxSlider({
          auto: true,
          pager: true,
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ecommerce_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\websites\arvind_infosis\pg\resources\views/home.blade.php ENDPATH**/ ?>