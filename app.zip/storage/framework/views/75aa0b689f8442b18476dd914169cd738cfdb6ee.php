

<?php $__env->startSection('content'); ?>
<?php $building = $room->building ?>
    <!-- Breadcrumb Begin -->
    <div class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__links">
                        <a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a>
                        <a href="#"><?php echo e($building->for); ?> </a>
                        <span><?php echo e($building->name); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- Product Details Section Begin -->
    <section class="product-details spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="product__details__pic">
                        <div class="product__details__pic__left product__thumb nice-scroll">
                            <a class="pt active" href="#product-<?php echo e($room->id); ?>">
                                <img src="<?php echo e(url($room->photo)); ?>" alt="">
                            </a>
                            <?php $__empty_1 = true; $__currentLoopData = $room->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a class="pt active" href="#image-<?php echo e($image->id); ?>">
                                <img src="<?php echo e(url($image->photo)); ?>" alt="photo">
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>

                        </div>
                        <div class="product__details__slider__content">
                            <div class="product__details__pic__slider owl-carousel">
                                <img data-hash="product-<?php echo e($room->id); ?>" class="product__big__img" src="<?php echo e(url($room->photo)); ?>" alt="">
                                <?php $__empty_1 = true; $__currentLoopData = $room->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <img data-hash="image-<?php echo e($image->id); ?>" class="product__big__img" src="<?php echo e($image->photo); ?>" alt="photo">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="product__details__text">
                        <h3><?php echo e($building->name); ?> <span>For: <?php echo e($building->for); ?></span></h3>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <span>( 138 reviews )</span>
                        </div>
                        <div class="product__details__price"><small>Max rent: </small>$ <?php echo e($room->max_rent); ?>.00 </div>
                        <div class="product__details__button">
                            <div class="quantity">
                                <span>Member want to visit:</span>
                                <div class="pro-qty">
                                    <input type="text" value="1">
                                </div>
                            </div>
                            <a href="#" class="cart-btn" data-id="<?php echo e($room->id); ?>">
                                <span class="icon_bag_alt"></span>Send visit request
                            </a>
                        </div>
                        <div class="product__details__widget">
                            <ul>
                                <li>
                                    <span>Room no:</span>
                                    <p><?php echo e($room->room_no); ?></p>
                                </li>
                                <li>
                                    <span>Total bed:</span>
                                    <p><?php echo e($room->bed); ?></p>
                                </li>
                                <li>
                                    <span>Available beds:</span>
                                    <p><?php echo e($room->available); ?></p>
                                </li>
                                <li>
                                    <span>Renter can live:</span>
                                    <p><?php echo e($room->renter); ?></p>
                                </li>
                                <li>
                                    <span>Max rent:</span>
                                    <p>$<?php echo e($room->max_rent); ?>.00 per month</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="product__details__tab">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Description</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab">Show on map</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab">Reviews ( 2 )</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane" id="tabs-1" role="tabpanel">
                                <h6>Description</h6>
                                <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut loret fugit, sed
                                    atem sequi nesciunt. Nulla
                                consequat massa quis enim.</p>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget
                                    dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,
                                    nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium
                                quis, sem.</p>
                            </div>
                            <div class="tab-pane" id="tabs-2" role="tabpanel">
                                <div id="map" style="height:400px"></div>
                            </div>
                            <div class="tab-pane" id="tabs-3" role="tabpanel">
                                <h6>Reviews ( 2 )</h6>
                                <p>Nptas sit aspernatur aut odit aut loret fugit, sed quia ipsu
                                    consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Nulla
                                consequat massa quis enim.</p>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="related__title">
                        <h5>TOTAL ROOMS IN THIS BUILDING (<?php echo e($building->rooms->count()); ?>)</h5>
                    </div>
                </div>
            </div>
            <div class="row property__gallery">
            <?php $i = 0; ?>
            <?php $__empty_1 = true; $__currentLoopData = $building->rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $i++; ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mix <?php echo e($building->for); ?>">
                <?php if($building->for == 'boys'): ?>
                <?php $class='new'; $label = 'Boys'; ?>
                <?php elseif($building->for == 'girls'): ?>
                <?php $class = 'sale'; $label = 'Girls' ?>
                <?php elseif($building->for == 'family'): ?>
                <?php $class='stockout'; $label = 'Family'; ?>
                <?php else: ?>
                <?php $class='stockout'; $label= 'Common' ?>
                <?php endif; ?>
                <div class="product__item <?php echo e($class); ?>">
                    <div class="product__item__pic set-bg" data-setbg="<?php echo e(url($room->photo)); ?>">
                        <div class="label <?php echo e($class); ?>"><?php echo e($label); ?></div>
                        <ul class="product__hover">
                            <li><a href="<?php echo e(url($room->photo)); ?>" class="image-popup"><span class="arrow_expand"></span></a></li>
                            <li><a href="#" class="addToWishlist" data-id="<?php echo e($room->id); ?>"><span class="icon_heart_alt"></span></a></li>
                            <li><a href="#" class="addToCart" data-id="<?php echo e($room->id); ?>"><span class="icon_bag_alt"></span></a></li>
                        </ul>
                    </div>
                    <div class="product__item__text">
                        <h6><a href="<?php echo e(url('room-details',$room->id)); ?>"><?php echo e($room->number); ?></a></h6>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <a href="<?php echo e(url('room-details',$room->id)); ?>"><?php echo e($room->building->name); ?></a>
                        Room No: <span><?php echo e($room->room_no); ?></span>
                        <div class="product__price">Available beds: <?php echo e($room->available); ?>

                            <span><?php echo e($room->bed); ?></span>
                        </div>
                        <small>Max rent: $ <span><?php echo e($room->max_rent); ?>.00 </span> per month</small>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>
        </div>
        </div>
    </section>
    <!-- Product Details Section End -->

<?php $__env->startSection('script'); ?>
      <script>
    function initMap(){
      var lat = <?php echo e($building->address->lat ? $building->address->lat : 23.344315); ?>;
      var lng = <?php echo e($building->address->lng ? $building->address->lng : 85.296013); ?>;

      var options = {
        zoom:8,
        center:{lat:lat,lng:lng}
      }

      // New map
      var map = new google.maps.Map(document.getElementById('map'), options);

        var markers = [
            <?php $__empty_1 = true; $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            {
            coords:{lat:<?php echo e($building->address->lat ? $building->address->lat : 0); ?>,lng:<?php echo e($building->address->lng ? $building->address->lng : 0); ?>},
            <?php if($building->id == $room->building->id): ?>
            iconImage:'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png',
            <?php endif; ?>
            content:'<h6><small>Name: </small><?php echo e($building->name); ?></h6><h6><small>Address: </small><?php echo e($building->address->area); ?></h6>'
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            {
                coords:{lat:0,lng:0}
            }
        ];

        for(var i = 0;i < markers.length;i++){
        // Add marker
        addMarker(markers[i]);
      }

      // Add Marker Function
      function addMarker(props){
        var marker = new google.maps.Marker({
          position:props.coords,
          map:map,
          //icon:props.iconImage
        });
        if(props.iconImage){
          // Set icon image
          marker.setIcon(props.iconImage);
        }

        // Check content
        if(props.content){
          var infoWindow = new google.maps.InfoWindow({
            content:props.content
          });

          marker.addListener('click', function(){
            infoWindow.open(map, marker);
          });
        }
      }



    }
  </script>
    <script async defer
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD2Zz2EofU165j4EdzGkK2klri-napBfIY&callback=initMap">
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ecommerce_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\websites\arvind_infosis\pg\resources\views/room-details.blade.php ENDPATH**/ ?>